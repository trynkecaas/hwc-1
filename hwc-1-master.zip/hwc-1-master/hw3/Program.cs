﻿int a = 5 ;
int os = a % 2; 
if (os == 0)
{
  Console.WriteLine(a);
   Console.Write("да");
}
else
{
  Console.WriteLine(a);
  Console.WriteLine("нет");
}

